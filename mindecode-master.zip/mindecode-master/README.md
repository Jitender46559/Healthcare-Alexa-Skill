We the Team MinDecode are building a skill for medical field that can tell information about the deseases. We are building this skill for amazon echo 
using amazon alexa and lambda function.

We are using node.js as interface connection and for backend also.
We are using two of your themes together i.e 
1. Medical
2. Smart Home

This skill will help user when their is any kind of medical emergency.

We also want to build an application using flutter and dart as programming language 
this can help us to navigate to that skill and from there user can enable this skill
and use it.